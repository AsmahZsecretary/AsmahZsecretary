
import { useState } from "react";
import { Card, CardContent } from "@components/ui/card";
import { Button } from "@components/ui/button";
import { Progress } from "@components/ui/progress";

const questions = [
  {
    question: "Un client vous envoie une facture en retard. Que faites-vous ?",
    options: [
      "Ignorer, ce n'est pas urgent",
      "Relancer gentiment avec un message professionnel",
      "Envoyer une lettre recommandée immédiatement",
    ],
    answer: 1,
  },
  {
    question: "Quel document est obligatoire pour une déclaration URSSAF ?",
    options: ["Le RIB", "La déclaration de chiffre d'affaires", "La carte d'identité"],
    answer: 1,
  },
  {
    question: "Classez les tâches par ordre de priorité :",
    options: [
      "1. Relancer une facture / 2. Répondre aux mails / 3. Faire une veille juridique",
      "1. Faire une veille juridique / 2. Répondre aux mails / 3. Relancer une facture",
      "1. Répondre aux mails / 2. Faire une veille juridique / 3. Relancer une facture",
    ],
    answer: 0,
  },
];

export default function AdminHeroGame() {
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (index: number) => {
    if (index === questions[step].answer) {
      setScore(score + 1);
    }
    if (step + 1 < questions.length) {
      setStep(step + 1);
    } else {
      setShowResult(true);
    }
  };

  const restartGame = () => {
    setStep(0);
    setScore(0);
    setShowResult(false);
  };

  return (
    <div className="max-w-xl mx-auto p-4">
      <h1 className="text-2xl font-bold text-center mb-4">🎯 Admin Hero – Le Challenge du Bureau</h1>

      {showResult ? (
        <Card className="text-center">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-2">Votre score : {score} / {questions.length}</h2>
            <p className="mb-4">
              {score === questions.length
                ? "⭐ Admin Hero confirmé ! Vous gérez comme un pro."
                : score >= 2
                ? "🔧 Bon niveau ! Encore un petit effort pour devenir Admin Hero."
                : "🚧 Besoin d'un coup de pouce ? Une secrétaire indépendante peut vous aider !"}
            </p>
            <Button onClick={restartGame}>Rejouer</Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold mb-2">{questions[step].question}</h2>
            <div className="space-y-2">
              {questions[step].options.map((opt, i) => (
                <Button key={i} className="w-full" onClick={() => handleAnswer(i)}>
                  {opt}
                </Button>
              ))}
            </div>
            <Progress value={((step + 1) / questions.length) * 100} className="mt-4" />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
